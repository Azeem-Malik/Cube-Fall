using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformSpwaner : MonoBehaviour
{

    public GameObject PlatformPrefab;
    public GameObject BreakablePlatfom;
    public GameObject[] Moving_Platform;
    public GameObject SpikePrefab;

    public float platform_Spawn_Time = 2f;
    private float Current_Spawn_Time;

    private int Platform_Count;
    public float min_X =-2, max_X =2;
    // Start is called before the first frame update
    void Start()
    {
        Current_Spawn_Time = platform_Spawn_Time;
    }

    // Update is called once per frame
    void Update()
    {
        SpawnPlatforms();
    }

    void SpawnPlatforms()
    {
        Current_Spawn_Time += Time.deltaTime;
        if(Current_Spawn_Time>=platform_Spawn_Time)
        {
            Platform_Count++;
            Vector3 temp = transform.position;
            temp.x = Random.Range(min_X, max_X);

            GameObject newPlatform = null;

             if(Platform_Count<2)
            {
                newPlatform = Instantiate(PlatformPrefab, temp, Quaternion.identity);
            }

             else if(Platform_Count==2)
            {
                if(Random.Range(0,2)>0)
                {
                    newPlatform = Instantiate(PlatformPrefab, temp, Quaternion.identity);
                }
                else
                {
                    newPlatform = Instantiate(Moving_Platform[Random.Range(0, Moving_Platform.Length)], temp, Quaternion.identity);
                }
            }

             else if(Platform_Count==3)
            {
                if(Random.Range(0,2)>0)
                {
                    newPlatform = Instantiate(PlatformPrefab, temp, Quaternion.identity);
                }
                else
                {
                    newPlatform = Instantiate(SpikePrefab, temp, Quaternion.identity);
                }
            }

             else if(Platform_Count==4)
            {
                if(Random.Range(0,2)>0)
                {
                    newPlatform = Instantiate(PlatformPrefab, temp, Quaternion.identity);
                }
                else
                {
                    newPlatform = Instantiate(BreakablePlatfom, temp, Quaternion.identity);
                }

                Platform_Count = 0;
            }

            newPlatform.transform.parent = transform;
            Current_Spawn_Time = 0f;

        }
    }
}
