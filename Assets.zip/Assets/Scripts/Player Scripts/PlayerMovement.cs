﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float Moving_Speed = 1f;
    private Rigidbody2D Mybody;

    // Start is called before the first frame update
    void Awake()
    {
        Mybody = GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        Move();
    }

    void Move()
    {
        if(ControlFreak2.CF2Input.GetAxisRaw("Horizontal")>0f)
        {
            Mybody.velocity = new Vector2(Moving_Speed, Mybody.velocity.y);
        }

        if(ControlFreak2.CF2Input.GetAxisRaw("Horizontal")<0f)
        {
            Mybody.velocity = new Vector2(-Moving_Speed, Mybody.velocity.y);
        }
    }

    public void plaformMove(float X)
    {
        Mybody.velocity = new Vector2(X, Mybody.velocity.y);
    }
}
