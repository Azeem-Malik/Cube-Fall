using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBounds : MonoBehaviour
{

    public float min_X = -2.6f, max_x = 2.6f, min_Y=-5.6f;

    private bool out_Of_Bounds;
    // Start is called before the first frame update
    

    // Update is called once per frame
    void Update()
    {
        CheckBounds();
    }

   void  CheckBounds()
    {
        Vector2 temp = transform.position;
        if(temp.x > max_x)
        {
            temp.x = max_x;
        }
        if(temp.x < min_X)
        {
            temp.x = min_X;
        }
        temp = transform.position;

        if(temp.y <= min_Y)
        {
            if(!out_Of_Bounds)
            {
                out_Of_Bounds = true;
                SoundManager.Instance.DeathSound();
                GameManager.Instance.RestartGame();
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag=="TopSpike")
        {
            gameObject.transform.position = new Vector2(1000f, 1000f);
            SoundManager.Instance.DeathSound();
            GameManager.Instance.RestartGame();
        }
    }
}
