using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour
{

    public static SoundManager Instance;

    [SerializeField]
    private AudioSource SoundFX;

    [SerializeField]
    private AudioClip landClip, deathClip, iceBreakClip, gameOverClip;

    void Awake()
    {
        if(Instance==null)
        {
            Instance = this;
        }
    }

    public void LandSound()
    {
        SoundFX.clip = landClip;
        SoundFX.Play();
    }

    public void DeathSound()
    {
        SoundFX.clip = deathClip;
        SoundFX.Play();
    }

    public void IceBreakSound()
    {
        SoundFX.clip = iceBreakClip;
        SoundFX.Play();
    }

    public void GameOverSound()
    {
        SoundFX.clip = gameOverClip;
        SoundFX.Play();
    }
}
